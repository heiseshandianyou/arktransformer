export class casts {
}
//# sourceMappingURL=cats.js.map