export class weatherModel {
    constructor() {
        this.forecasts = [];
    }
}
//# sourceMappingURL=WeatherModel.js.map